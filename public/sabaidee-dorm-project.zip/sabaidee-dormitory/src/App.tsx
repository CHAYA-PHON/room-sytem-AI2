/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { 
  Building, 
  DoorClosed, 
  Users, 
  Gauge, 
  FileSpreadsheet, 
  DollarSign, 
  History, 
  Settings, 
  LogOut, 
  Lock, 
  Eye, 
  ChevronRight,
  ChevronLeft,
  Info,
  Layers,
  Database,
  Cloud,
  Sparkles,
  Activity,
  RotateCcw,
  Download,
  X,
  ExternalLink
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

// Import simulated DB layers
import { 
  seedDatabase, 
  resetToDefaultSeedData,
  getRooms, 
  saveRoom, 
  deleteRoom,
  getTenants,
  saveTenant,
  deleteTenant,
  getBankAccounts,
  saveBankAccount,
  deleteBankAccount,
  getMeterEntryList,
  getMeters,
  saveMetersBatch,
  deleteMeterReading,
  getBills,
  getBillsList,
  recalcBill,
  getPaymentHistory,
  payBillsFIFO,
  deletePayment,
  updatePayment,
  getAdmins,
  saveAdmin,
  deleteAdmin,
  loginUser,
  getDashboardData,
  getAllAddedItems,
  getAddedItems,
  saveAddedItem,
  deleteAddedItem,
  getUtilityRates,
  saveUtilityRate,
  deleteUtilityRate,
  getBillAnnouncements,
  saveBillAnnouncement,
  deleteBillAnnouncement,
  getOwnerInfo,
  saveOwnerInfo
} from "./dbSim";

import { Room, Tenant, BankAccount, AddedItem, Bill, PaymentRecord, Admin, UtilityRate, BillAnnouncement, OwnerInfo } from "./types";

// Import Sub Components
import Dashboard from "./components/Dashboard";
import Rooms from "./components/Rooms";
import Tenants from "./components/Tenants";
import Meters from "./components/Meters";
import Bills from "./components/Bills";
import Banks from "./components/Banks";
import PaymentHistory from "./components/PaymentHistory";
import AdminSettings from "./components/AdminSettings";
import PrintPreview from "./components/PrintPreview";
import AIAnalytics from "./components/AIAnalytics";

// Import Google Sheets sync service
import { 
  getGsUrl, 
  saveGsUrl, 
  getLastSyncTime, 
  pushToGoogleSheets, 
  pullFromGoogleSheets,
  DEFAULT_GS_URL,
  pullDirectFromGoogleSheets
} from "./sheetsSync";

export default function App() {
  // Authentication session
  const [user, setUser] = useState<{ id: string; username: string } | null>(null);
  const [loginUsername, setLoginUsername] = useState("");
  const [loginPin, setLoginPin] = useState("");
  const [loginError, setLoginError] = useState("");
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isDownloadModalOpen, setIsDownloadModalOpen] = useState(false);
  const [isDownloadingZip, setIsDownloadingZip] = useState(false);

  const handleDownloadProject = async () => {
    setIsDownloadingZip(true);
    try {
      const response = await fetch("/api/download-project");
      if (!response.ok) throw new Error("Download failed");
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = "sabaidee-dorm-project.zip";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
    } catch (err) {
      console.warn("Direct blob download fallback to new tab:", err);
      window.open("/api/download-project", "_blank");
    } finally {
      setIsDownloadingZip(false);
    }
  };

  // System general month selection
  const [month, setMonth] = useState<string>("2026-07");

  // Current selected tab index
  const [activeTab, setActiveTab] = useState<string>("dashboard");

  // Sidebar collapsed state for desktop
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState<boolean>(() => {
    return localStorage.getItem("dorm_sidebar_collapsed") === "true";
  });

  useEffect(() => {
    localStorage.setItem("dorm_sidebar_collapsed", isSidebarCollapsed.toString());
  }, [isSidebarCollapsed]);

  // State caches for reactive UI binding
  const [rooms, setRooms] = useState<Room[]>([]);
  const [tenants, setTenants] = useState<Tenant[]>([]);
  const [banks, setBanks] = useState<BankAccount[]>([]);
  const [metersList, setMetersList] = useState<any[]>([]);
  const [bills, setBills] = useState<Bill[]>([]);
  const [payments, setPayments] = useState<PaymentRecord[]>([]);
  const [admins, setAdmins] = useState<Admin[]>([]);
  const [utilityRates, setUtilityRates] = useState<UtilityRate[]>([]);
  const [billAnnouncements, setBillAnnouncements] = useState<BillAnnouncement[]>([]);
  const [ownerInfo, setOwnerInfo] = useState<OwnerInfo>({ name: "", phone: "" });
  const [dashboardStats, setDashboardStats] = useState<any>(null);
  const [addedItemsList, setAddedItemsList] = useState<AddedItem[]>([]);

  // Real-time synchronization state listener
  const [realtimeSyncStatus, setRealtimeSyncStatus] = useState<{
    status: "idle" | "syncing" | "success" | "error";
    message?: string;
    time?: string;
  }>({ status: "idle" });

  useEffect(() => {
    const handleStatus = (e: Event) => {
      const detail = (e as CustomEvent).detail;
      setRealtimeSyncStatus(detail);
      if (detail.status === "success" && detail.time) {
        setLastSyncTimeState(detail.time);
      }
    };
    window.addEventListener("dorm_realtime_sync_status", handleStatus);
    return () => {
      window.removeEventListener("dorm_realtime_sync_status", handleStatus);
    };
  }, []);

  // Counter to notify real-time sheets database drawer of updates
  const [refreshSheetsTrigger, setRefreshSheetsTrigger] = useState<number>(0);

  // Google Sheets integration state variables
  const [gsUrl, setGsUrl] = useState<string>("");
  const [lastSyncTime, setLastSyncTimeState] = useState<string>("ยังไม่ได้ซิงค์");
  const [isSyncing, setIsSyncing] = useState<boolean>(false);

  // Print system overlay states
  const [printConfig, setPrintConfig] = useState<{
    isOpen: boolean;
    type: "invoices" | "summary";
    selectedRoomIds: string[];
  }>({
    isOpen: false,
    type: "invoices",
    selectedRoomIds: []
  });

  // Seed database once at load time
  useEffect(() => {
    seedDatabase();
    refreshAllState();

    // Initialize Google Sheets state
    const initialUrl = getGsUrl();
    setGsUrl(initialUrl);
    setLastSyncTimeState(getLastSyncTime());

    // Recover login session from local storage if existing and validate it
    const session = localStorage.getItem("dorm_user_session");
    if (session) {
      try {
        const parsed = JSON.parse(session);
        const currentAdmins = getAdmins();
        const stillExists = currentAdmins.some(a => a.id === parsed.id && a.username === parsed.username);
        if (stillExists) {
          setUser(parsed);
        } else {
          localStorage.removeItem("dorm_user_session");
          setUser(null);
        }
      } catch (e) {
        localStorage.removeItem("dorm_user_session");
      }
    }

    // Auto-pull from Google Sheets on app startup (as requested: "เมื่อเปิดแอป ให้โหลดข้อมูลจาก google sheet ทันที่ ไม่ต้องรอเข้าระบบ")
    const autoPullFromSheetsOnLoad = async () => {
      // A. Try direct Google Sheets OAuth API first if credentials exist
      const directSheetId = localStorage.getItem("sabaidee_dorm_direct_sheet_id");
      const googleToken = localStorage.getItem("sabaidee_dorm_google_token");
      
      if (directSheetId && googleToken) {
        console.log("Auto-pulling from Direct Google Sheets OAuth API...");
        try {
          const result = await pullDirectFromGoogleSheets(directSheetId, googleToken);
          if (result.success) {
            console.log("Auto-pull startup success (Direct API):", result.message);
            setLastSyncTimeState(getLastSyncTime());
            refreshAllState();
            return;
          } else {
            console.warn("Auto-pull startup failed (Direct API):", result.message);
          }
        } catch (error) {
          console.warn("Auto-pull startup error (Direct API):", error);
        }
      }

      // B. Fallback/Standard: Pull from Google Sheets using Web App (Apps Script URL)
      const targetUrl = initialUrl || getGsUrl();
      if (targetUrl) {
        console.log("Auto-pulling from Google Sheets Apps Script Web App...");
        try {
          const result = await pullFromGoogleSheets(targetUrl);
          if (result.success) {
            console.log("Auto-pull startup success (Apps Script):", result.message);
            setLastSyncTimeState(getLastSyncTime());
            refreshAllState();
          } else {
            console.warn("Auto-pull startup failed (Apps Script):", result.message);
          }
        } catch (error) {
          console.warn("Auto-pull startup error (Apps Script):", error);
        }
      }
    };

    autoPullFromSheetsOnLoad();
  }, []);

  // Whenever the month or general mutations occur, reload dependent states
  useEffect(() => {
    refreshAllState();
  }, [month, user]);

  const refreshAllState = () => {
    const loadedRooms = getRooms();
    const loadedTenants = getTenants();
    const loadedBanks = getBankAccounts();
    const loadedMeters = getMeterEntryList(month);
    
    // Ensure all bills are recalculated dynamically
    loadedRooms.forEach(r => {
      // Run recalculation to ensure current addedItems, FIFO changes and old balances match perfectly
      recalcBill(r.id, month);
    });

    const loadedBills = getBillsList(month);
    const loadedPayments = getPaymentHistory(month);
    const loadedAdmins = getAdmins();
    const loadedRates = getUtilityRates();
    const loadedAnncs = getBillAnnouncements();
    const loadedOwnerInfo = getOwnerInfo();
    const loadedDashboard = getDashboardData(month);
    const loadedAddedItems = getAllAddedItems().filter(it => it.month === month);

    setRooms(loadedRooms);
    setTenants(loadedTenants);
    setBanks(loadedBanks);
    setMetersList(loadedMeters);
    setBills(loadedBills);
    setPayments(loadedPayments);
    setAdmins(loadedAdmins);
    setUtilityRates(loadedRates);
    setBillAnnouncements(loadedAnncs);
    setOwnerInfo(loadedOwnerInfo);
    setDashboardStats(loadedDashboard);
    setAddedItemsList(loadedAddedItems);

    setRefreshSheetsTrigger(prev => prev + 1);
  };

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError("");

    const res = loginUser(loginUsername, loginPin);
    if (res.success && res.user) {
      setUser(res.user);
      localStorage.setItem("dorm_user_session", JSON.stringify(res.user));
    } else {
      setLoginError(res.message || "ล้มเหลว");
    }
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem("dorm_user_session");
  };

  // --- MUTATION WRAPPERS WITH REACTIVE REFRESH ---
  const triggerAutoPush = async () => {
    const currentUrl = getGsUrl();
    if (!currentUrl) return;

    setIsSyncing(true);
    console.log("Auto-sync: Saving updates to Google Sheets...");
    try {
      const result = await pushToGoogleSheets(currentUrl);
      setLastSyncTimeState(getLastSyncTime());
      console.log("Auto-sync success:", result.message);
    } catch (error) {
      console.warn("Auto-sync failed to push to Google Sheets:", error);
    } finally {
      setIsSyncing(false);
    }
  };

  const handleSaveRoom = (room: Room) => {
    saveRoom(room);
    refreshAllState();
    triggerAutoPush();
  };

  const handleDeleteRoom = (id: string) => {
    deleteRoom(id);
    refreshAllState();
    triggerAutoPush();
  };

  const handleSaveTenant = (tenant: Tenant) => {
    saveTenant(tenant);
    // Auto recalc bills on new contract creation
    refreshAllState();
    triggerAutoPush();
  };

  const handleDeleteTenant = (roomId: string) => {
    deleteTenant(roomId);
    refreshAllState();
    triggerAutoPush();
  };

  const handleSaveBanks = (bank: BankAccount) => {
    saveBankAccount(bank);
    refreshAllState();
    triggerAutoPush();
  };

  const handleDeleteBanks = (id: string) => {
    deleteBankAccount(id);
    refreshAllState();
    triggerAutoPush();
  };

  const handleSaveMetersBatch = (items: any[]) => {
    saveMetersBatch(month, items, user?.username || "admin");
    refreshAllState();
    triggerAutoPush();
    setTimeout(() => {
      alert(`บันทึกค่ามิเตอร์จำนวน ${items.length} ห้อง และประมวลผลจัดเก็บสำเร็จ!`);
    }, 100);
    setActiveTab("payments"); // Auto transition to payments (Transaction History)
  };

  const handleDeleteMeterReading = (roomId: string) => {
    if (window.confirm("⚠️ คุณแน่ใจหรือไม่ว่าต้องการลบข้อมูลมิเตอร์และการบันทึกค่าในรอบเดือนนี้? บิลสรุปค่าใช้จ่ายของห้องนี้จะถูกลบไปด้วย")) {
      deleteMeterReading(roomId, month);
      refreshAllState();
      triggerAutoPush();
    }
  };

  const handleUpdateMeterReading = (item: any) => {
    saveMetersBatch(month, [item], user?.username || "admin");
    refreshAllState();
    triggerAutoPush();
  };

  const handlePayFIFO = (roomId: string, amount: number, method: "เงินสด" | "โอนธนาคาร", receiver: string, note: string) => {
    const result = payBillsFIFO(roomId, amount, method, receiver, note);
    refreshAllState();
    triggerAutoPush();
    setTimeout(() => {
      if (result.success) {
        alert("บันทึกรับเงินตัดบิล FIFO เรียบร้อย!");
      } else {
        alert(result.message || "เกิดข้อผิดพลาด");
      }
    }, 100);
  };

  const handleDeletePayment = (payId: string) => {
    if (window.confirm("⚠️ คุณแน่ใจหรือไม่ว่าต้องการยกเลิกและลบประวัติการชำระเงินรายการนี้? ยอดเงินที่จ่ายในบิลจะถูกปรับลดลง และยอดหนี้คงเหลืออาจเพิ่มขึ้น")) {
      const result = deletePayment(payId);
      refreshAllState();
      triggerAutoPush();
      setTimeout(() => {
        if (result.success) {
          alert("ลบประวัติการชำระเงินและอัปเดตยอดบิลที่เกี่ยวข้องเรียบร้อยแล้ว!");
        } else {
          alert(result.message || "เกิดข้อผิดพลาดในการลบ");
        }
      }, 100);
    }
  };

  const handleUpdatePayment = (payId: string, updatedFields: Partial<PaymentRecord>) => {
    const result = updatePayment(payId, updatedFields);
    refreshAllState();
    triggerAutoPush();
    setTimeout(() => {
      if (result.success) {
        alert("แก้ไขข้อมูลประวัติการชำระเงินเรียบร้อยแล้ว!");
      } else {
        alert(result.message || "เกิดข้อผิดพลาดในการแก้ไข");
      }
    }, 100);
  };

  const handleBulkPay = (payments: { roomId: string; amount: number; method: "เงินสด" | "โอนธนาคาร"; receiver: string; note: string }[]) => {
    let successRooms: string[] = [];
    let errorRooms: string[] = [];

    payments.forEach(p => {
      const result = payBillsFIFO(p.roomId, p.amount, p.method, p.receiver, p.note);
      if (result.success) {
        successRooms.push(p.roomId);
      } else {
        errorRooms.push(p.roomId);
      }
    });

    refreshAllState();
    triggerAutoPush();
    setTimeout(() => {
      if (successRooms.length > 0) {
        alert(`บันทึกชำระเงินตัดบิล FIFO สำเร็จเรียบร้อยสำหรับ ${successRooms.length} ห้อง!${errorRooms.length > 0 ? ` (ล้มเหลว ${errorRooms.length} ห้อง)` : ""}`);
      } else {
        alert("ไม่สามารถบันทึกการชำระเงินได้");
      }
    }, 100);
  };

  const handleSaveAdmin = (admin: Admin) => {
    saveAdmin(admin);
    refreshAllState();
    triggerAutoPush();
  };

  const handleSaveOwnerInfo = (info: OwnerInfo) => {
    saveOwnerInfo(info);
    refreshAllState();
    triggerAutoPush();
  };

  const handleDeleteAdmin = (id: string) => {
    deleteAdmin(id);
    refreshAllState();
    triggerAutoPush();
  };

  const handleSaveUtilityRate = (rate: UtilityRate) => {
    saveUtilityRate(rate);
    refreshAllState();
    triggerAutoPush();
  };

  const handleDeleteUtilityRate = (id: string) => {
    const res = deleteUtilityRate(id);
    if (!res.success) {
      alert(res.message);
    } else {
      refreshAllState();
      triggerAutoPush();
    }
  };

  const handleSaveBillAnnouncement = (annc: BillAnnouncement) => {
    saveBillAnnouncement(annc);
    refreshAllState();
    triggerAutoPush();
  };

  const handleDeleteBillAnnouncement = (id: string) => {
    deleteBillAnnouncement(id);
    refreshAllState();
    triggerAutoPush();
  };

  const handleSaveAddedItemWrapper = (item: AddedItem) => {
    saveAddedItem(item);
    refreshAllState();
    triggerAutoPush();
  };

  const handleDeleteAddedItemWrapper = (id: string, roomId: string, month: string) => {
    deleteAddedItem(id, roomId, month);
    refreshAllState();
    triggerAutoPush();
  };

  // --- GOOGLE SHEETS SYNC ACTIONS ---
  const handleSaveGsUrl = (url: string) => {
    saveGsUrl(url);
    setGsUrl(url);
  };

  const handlePushToSheets = async (url?: string) => {
    setIsSyncing(true);
    const targetUrl = url ? url.trim() : gsUrl.trim();
    if (targetUrl && targetUrl !== gsUrl) {
      handleSaveGsUrl(targetUrl);
    }
    const result = await pushToGoogleSheets(targetUrl || gsUrl);
    setIsSyncing(false);
    setLastSyncTimeState(getLastSyncTime());
    alert(result.message);
  };

  const handlePullFromSheets = async (url?: string) => {
    setIsSyncing(true);
    const targetUrl = url ? url.trim() : gsUrl.trim();
    if (targetUrl && targetUrl !== gsUrl) {
      handleSaveGsUrl(targetUrl);
    }
    const result = await pullFromGoogleSheets(targetUrl || gsUrl);
    setIsSyncing(false);
    setLastSyncTimeState(getLastSyncTime());
    if (result.success) {
      alert("ดึงข้อมูลจาก Google Sheets สำเร็จ! ระบบกำลังอัปเดตหน้าจอหลัก...");
      refreshAllState();
    } else {
      alert(result.message);
    }
  };

  const handleResetLocalDatabase = () => {
    if (confirm("คุณแน่ใจหรือไม่ที่จะล้างข้อมูลปัจจุบันทั้งหมด และย้อนกลับไปใช้ชุดข้อมูลทดสอบเริ่มต้น (Seed Data) ระบบจะโหลดหน้าจอใหม่หลังจากคืนค่าสำเร็จ")) {
      resetToDefaultSeedData();
      refreshAllState();
      window.location.reload();
    }
  };

  const handleRestartSystem = () => {
    if (confirm("คุณแน่ใจหรือไม่ที่จะเริ่มระบบใหม่? (ระบบจะโหลดหน้าจอใหม่โดยไม่มีการล้างข้อมูลใดๆ)")) {
      window.location.reload();
    }
  };

  // Render Login overlay if session does not exist
  if (!user) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8 font-sans antialiased text-slate-800 animate-in fade-in duration-300">
        <div className="sm:mx-auto sm:w-full sm:max-w-md text-center space-y-3 px-4">
          <div className="inline-flex p-3 bg-blue-600 text-white rounded-2xl shadow-lg shadow-blue-600/20">
            <Building className="w-8 h-8" />
          </div>
          <h2 className="text-2xl font-black text-slate-900 tracking-tight">นิติบุคคล ระบบบริหารจัดการหอพัก</h2>
          <p className="text-xs text-slate-400 font-bold uppercase tracking-wider">Dormitory Smart Manager Portal</p>
        </div>

        <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md px-4">
          <div className="bg-white py-8 px-6 shadow-xl rounded-3xl border border-slate-100 space-y-6">
            
            {/* Quick Credentials Info Alert */}
            <div className="bg-blue-50/50 p-4 rounded-xl border border-blue-100 flex items-start space-x-2 text-xs text-blue-800 leading-relaxed">
              <Info className="w-4 h-4 shrink-0 text-blue-500 mt-0.5" />
              <div>
                <strong className="block text-slate-800 font-bold mb-1">แนะนำการใช้งานระบบนิติบุคคล</strong>
                <p className="text-slate-600 font-medium">
                  เข้าสู่ระบบนิติบุคคลเพื่อทดสอบและใช้งานการจัดการหอพัก จัดการสัญญาผู้เช่า บันทึกหน่วยน้ำ-ไฟล่าสุด และพิมพ์บิลหรือใบแจ้งหนี้แบบสรุปยอดค้างชำระ
                </p>
              </div>
            </div>

            <form onSubmit={handleLoginSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase mb-1.5">ชื่อผู้ใช้นิติบุคคล</label>
                <input 
                  type="text"
                  required
                  value={loginUsername}
                  onChange={(e) => setLoginUsername(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white text-slate-800 font-semibold text-sm"
                  placeholder="admin"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase mb-1.5">รหัส PIN 6 หลัก</label>
                <input 
                  type="password"
                  required
                  maxLength={6}
                  value={loginPin}
                  onChange={(e) => setLoginPin(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white text-center font-mono tracking-widest text-lg font-black text-slate-800"
                  placeholder="••••••"
                />
              </div>

              {loginError && (
                <div className="text-xs text-rose-500 font-bold bg-rose-50 p-3 rounded-lg border border-rose-100">
                  ⚠️ {loginError}
                </div>
              )}

              <button
                type="submit"
                className="w-full py-3.5 px-4 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl text-sm transition-all shadow-md shadow-blue-500/15 cursor-pointer"
              >
                ยืนยันเพื่อความปลอดภัยล็อกอิน
              </button>
            </form>
          </div>
        </div>
      </div>
    );
  }

  // Define sidebar menu options
  const sidebarItems = [
    { id: "dashboard", label: "หน้าภาพรวมหลัก", icon: Building },
    { id: "rooms", label: "จัดการห้องพัก", icon: DoorClosed },
    { id: "tenants", label: "สัญญาผู้เช่าอาศัย", icon: Users },
    { id: "meters", label: "จดจดมิเตอร์กลุ่ม", icon: Gauge },
    { id: "bills", label: "บิลสรุปประจำงวด", icon: FileSpreadsheet },
    { id: "ai", label: "เปรียบเทียบการใช้น้ำไฟ", icon: Activity },
    { id: "payments", label: "ประวัติทำรายการ", icon: History },
    { id: "admin", label: "ตั้งค่าแอดมิน", icon: Settings }
  ];

  return (
    <div className="min-h-screen bg-[#f8fafc] flex flex-col md:flex-row font-sans antialiased text-slate-800">
      
      {/* Mobile Top Header */}
      <div className="md:hidden no-print bg-[#2563eb] text-white flex items-center justify-between px-5 py-4 sticky top-0 z-40 shadow-md shrink-0">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 bg-white rounded-lg flex items-center justify-center shrink-0 shadow-sm">
            <Building className="w-5 h-5 text-[#2563eb]" />
          </div>
          <div>
            <h1 className="text-sm font-extrabold tracking-tight leading-none text-white">SABAIDEE DORM</h1>
            <p className="text-[9px] text-white/70 font-bold mt-1 uppercase tracking-wider flex items-center gap-1.5">
              <span>Dorm Ops Portal</span>
              <span className="text-[8px] bg-white/20 text-white px-1 py-0.5 rounded font-mono font-bold tracking-normal leading-none">V.2026-PB02_2.8</span>
              <span className={`w-1.5 h-1.5 rounded-full ${
                realtimeSyncStatus.status === "syncing" ? "bg-amber-400 animate-pulse" :
                realtimeSyncStatus.status === "success" ? "bg-emerald-400" :
                realtimeSyncStatus.status === "error" ? "bg-rose-400" : "bg-emerald-400"
              }`} title="Real-time sync" />
            </p>
          </div>
        </div>
        <button 
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          className="p-2 bg-white/10 hover:bg-white/20 active:bg-white/30 rounded-lg transition-all focus:outline-none"
          aria-label="Toggle menu"
        >
          {isMobileMenuOpen ? (
            <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
            </svg>
          ) : (
            <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" d="M4 6h16M4 12h16M4 18h16" />
            </svg>
          )}
        </button>
      </div>

      {/* Mobile Menu Drawer Overlay */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <>
            {/* Dark backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.5 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsMobileMenuOpen(false)}
              className="fixed inset-0 bg-black/60 z-40 md:hidden no-print"
            />
            {/* Slide-out Panel */}
            <motion.aside
              initial={{ x: "-100%" }}
              animate={{ x: 0 }}
              exit={{ x: "-100%" }}
              transition={{ type: "tween", duration: 0.2 }}
              className="fixed top-0 bottom-0 left-0 w-72 bg-[#2563eb] text-white flex flex-col z-50 p-5 shadow-2xl md:hidden overflow-y-auto no-print"
            >
              {/* Brand Header */}
              <div className="flex items-center justify-between border-b border-white/10 pb-4 mb-5 shrink-0">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-white rounded-lg flex items-center justify-center shrink-0 shadow-md">
                    <Building className="w-5 h-5 text-[#2563eb]" />
                  </div>
                  <div>
                    <h1 className="text-base font-extrabold tracking-tight leading-none text-white">SABAIDEE DORM</h1>
                    <p className="text-[10px] text-white/70 font-bold mt-1 uppercase tracking-wider flex items-center gap-1.5">
                      <span>Dorm Ops Portal</span>
                      <span className="text-[8px] bg-white/20 text-white px-1 py-0.5 rounded font-mono font-bold tracking-normal leading-none">V.2026-PB02_2.8</span>
                    </p>
                  </div>
                </div>
                <button 
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="p-1.5 hover:bg-white/10 active:bg-white/25 rounded-lg text-white"
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>

              {/* Menu lists */}
              <nav className="flex-1 space-y-1">
                {sidebarItems.map(item => {
                  const Icon = item.icon;
                  const isActive = activeTab === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => {
                        setActiveTab(item.id);
                        setIsMobileMenuOpen(false);
                      }}
                      className={`w-full flex items-center justify-between px-4 py-3 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                        isActive 
                          ? "bg-white/15 text-white shadow-sm" 
                          : "text-white/75 hover:bg-white/5 hover:text-white"
                      }`}
                    >
                      <div className="flex items-center space-x-3">
                        <Icon className="w-4.5 h-4.5 shrink-0" />
                        <span>{item.label}</span>
                      </div>
                      <ChevronRight className={`w-3.5 h-3.5 transition-transform ${isActive ? "opacity-100 translate-x-0.5" : "opacity-0"}`} />
                    </button>
                  );
                })}
              </nav>

              {/* Profile/Logout footer */}
              <div className="border-t border-white/10 mt-auto pt-4 shrink-0">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-full bg-blue-400/30 border-2 border-white/20 flex items-center justify-center text-white font-extrabold text-xs uppercase shadow-inner shrink-0">
                    {user.username.slice(0, 2)}
                  </div>
                  <div className="overflow-hidden flex-1">
                    <p className="text-sm font-semibold truncate text-white">{user.username}</p>
                    <p className="text-[10px] text-white/60 font-bold uppercase tracking-wider">ผู้จัดการหอพัก</p>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <button 
                      onClick={() => setIsDownloadModalOpen(true)}
                      className="p-2 bg-white/10 hover:bg-blue-500/30 text-white/80 hover:text-white rounded-lg transition-colors cursor-pointer"
                      title="ดาวน์โหลดไฟล์ APP (.ZIP) ลงเครื่อง PC"
                      id="mobile-download-app-btn"
                    >
                      <Download className="w-3.5 h-3.5" />
                    </button>
                    <button 
                      onClick={handleRestartSystem}
                      className="p-2 bg-white/10 hover:bg-emerald-600/30 text-white/80 hover:text-white rounded-lg transition-colors cursor-pointer"
                      title="เริ่มระบบใหม่ (Restart)"
                      id="mobile-reset-db-btn"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                    </button>
                    <button 
                      onClick={() => {
                        setIsMobileMenuOpen(false);
                        handleLogout();
                      }}
                      className="p-2 bg-white/10 hover:bg-rose-600/30 text-white/80 hover:text-white rounded-lg transition-colors cursor-pointer"
                      title="ออกจากระบบ"
                    >
                      <LogOut className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            </motion.aside>
          </>
        )}
      </AnimatePresence>

      {/* Navigation Left Sidebar (Desktop Only) */}
      <aside className={`hidden md:flex no-print ${isSidebarCollapsed ? "w-20 px-3 py-6" : "w-64 p-4 md:p-6"} bg-[#2563eb] text-white flex-col shrink-0 border-r border-[#1e40af] transition-all duration-300 relative`}>
        {/* Collapse Toggle Button */}
        <button
          onClick={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
          className="absolute -right-3 top-7 w-6 h-6 rounded-full bg-white text-[#2563eb] border border-slate-200 flex items-center justify-center shadow-md hover:scale-110 active:scale-95 transition-all cursor-pointer z-50"
          title={isSidebarCollapsed ? "ขยายแถบเมนู" : "ย่อ/ซ้อนแถบเมนู"}
        >
          {isSidebarCollapsed ? (
            <ChevronRight className="w-3.5 h-3.5" />
          ) : (
            <ChevronLeft className="w-3.5 h-3.5" />
          )}
        </button>

        {/* Brand Header */}
        <div className={`p-2 flex items-center ${isSidebarCollapsed ? "justify-center" : "gap-3"} border-b border-white/10 pb-5 mb-4 shrink-0`}>
          <div className="w-8 h-8 bg-white rounded-lg flex items-center justify-center shrink-0 shadow-md">
            <Building className="w-5 h-5 text-[#2563eb]" />
          </div>
          {!isSidebarCollapsed && (
            <div className="overflow-hidden transition-all duration-300">
              <h1 className="text-base font-extrabold tracking-tight leading-none text-white whitespace-nowrap">SABAIDEE DORM</h1>
              <p className="text-[10px] text-white/70 font-bold mt-1 uppercase tracking-wider flex items-center gap-1.5">
                <span>Dorm Ops Portal</span>
                <span className="text-[8px] bg-white/20 text-white px-1.5 py-0.5 rounded font-mono font-bold tracking-normal leading-none">V.2026-PB02_2.8</span>
              </p>
            </div>
          )}
        </div>

        {/* Real-time Google Sheets Sync Badge */}
        {isSidebarCollapsed ? (
          <div className="flex justify-center mb-4">
            <div className={`p-1.5 rounded-full ${
              realtimeSyncStatus.status === "syncing" ? "bg-amber-400 animate-pulse text-slate-900" :
              realtimeSyncStatus.status === "success" ? "bg-emerald-500/20 text-emerald-300" :
              realtimeSyncStatus.status === "error" ? "bg-rose-500/20 text-rose-300" : "bg-white/10 text-white/60"
            }`} title="เชื่อมโยง Google Sheet เรียลไทม์">
              <Cloud className="w-4 h-4" />
            </div>
          </div>
        ) : (
          <div className="mx-2 mb-4 p-2.5 bg-white/5 hover:bg-white/10 rounded-xl border border-white/10 text-[11px] text-white/90 transition-all">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5 font-bold">
                <Cloud className={`w-3.5 h-3.5 ${realtimeSyncStatus.status === "syncing" ? "text-amber-400 animate-bounce" : "text-emerald-400"}`} />
                <span>Google Sheet: เรียลไทม์</span>
              </div>
              <span className={`w-1.5 h-1.5 rounded-full ${
                realtimeSyncStatus.status === "syncing" ? "bg-amber-400 animate-pulse" :
                realtimeSyncStatus.status === "success" ? "bg-emerald-400" :
                realtimeSyncStatus.status === "error" ? "bg-rose-400" : "bg-emerald-400"
              }`} />
            </div>
            <p className="mt-1 text-[10px] text-white/60 font-medium">
              {realtimeSyncStatus.status === "syncing" && "กำลังส่งข้อมูลอัตโนมัติ..."}
              {realtimeSyncStatus.status === "success" && `ซิงค์เรียลไทม์สำเร็จ: ${realtimeSyncStatus.time || "เรียบร้อย"}`}
              {realtimeSyncStatus.status === "error" && "การเชื่อมโยงเรียลไทม์ติดขัด"}
              {realtimeSyncStatus.status === "idle" && "ระบบเรียลไทม์พร้อมทำงาน"}
            </p>
          </div>
        )}

        {/* Navigation links list */}
        <nav className="flex-1 space-y-1.5">
          {sidebarItems.map(item => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center ${isSidebarCollapsed ? "justify-center px-2" : "justify-between px-4"} py-3 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  isActive 
                    ? "bg-white/10 text-white shadow-sm" 
                    : "text-white/75 hover:bg-white/5 hover:text-white"
                }`}
                title={isSidebarCollapsed ? item.label : undefined}
              >
                <div className="flex items-center space-x-3">
                  <Icon className="w-4.5 h-4.5 shrink-0" />
                  {!isSidebarCollapsed && <span className="whitespace-nowrap">{item.label}</span>}
                </div>
                {!isSidebarCollapsed && (
                  <ChevronRight className={`w-3.5 h-3.5 transition-transform ${isActive ? "opacity-100 translate-x-0.5" : "opacity-0"}`} />
                )}
              </button>
            );
          })}
        </nav>

        {/* Profile and Logout footer */}
        <div className={`border-t border-white/10 mt-auto pt-4 shrink-0 ${isSidebarCollapsed ? "px-1" : "p-2 md:p-3"}`}>
          <div className={`flex items-center ${isSidebarCollapsed ? "flex-col gap-4 justify-center" : "gap-3"}`}>
            <div className="w-10 h-10 rounded-full bg-blue-400/30 border-2 border-white/20 flex items-center justify-center text-white font-extrabold text-xs uppercase shadow-inner shrink-0" title={user.username}>
              {user.username.slice(0, 2)}
            </div>
            {!isSidebarCollapsed && (
              <div className="overflow-hidden flex-1">
                <p className="text-sm font-semibold truncate text-white">{user.username}</p>
                <p className="text-[10px] text-white/60 font-bold uppercase tracking-wider">ผู้จัดการหอพัก</p>
              </div>
            )}
            {isSidebarCollapsed ? (
              <div className="flex flex-col items-center gap-2 w-full">
                <button 
                  onClick={() => setIsDownloadModalOpen(true)}
                  className="p-2 bg-white/10 hover:bg-blue-500/30 text-white/80 hover:text-white rounded-lg transition-colors cursor-pointer w-full flex justify-center"
                  title="ดาวน์โหลดไฟล์ APP (.ZIP) ลงเครื่อง PC"
                  id="sidebar-download-app-btn-collapsed"
                >
                  <Download className="w-3.5 h-3.5" />
                </button>
                <button 
                  onClick={handleRestartSystem}
                  className="p-2 bg-white/10 hover:bg-emerald-600/30 text-white/80 hover:text-white rounded-lg transition-colors cursor-pointer w-full flex justify-center"
                  title="เริ่มระบบใหม่ (Restart)"
                  id="sidebar-reset-db-btn-collapsed"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                </button>
                <button 
                  onClick={handleLogout}
                  className="p-2 bg-white/10 hover:bg-rose-600/30 text-white/80 hover:text-white rounded-lg transition-colors cursor-pointer w-full flex justify-center"
                  title="ออกจากระบบ"
                >
                  <LogOut className="w-3.5 h-3.5" />
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-1.5">
                <button 
                  onClick={() => setIsDownloadModalOpen(true)}
                  className="p-2 bg-white/10 hover:bg-blue-500/30 text-white/80 hover:text-white rounded-lg transition-colors cursor-pointer"
                  title="ดาวน์โหลดไฟล์ APP (.ZIP) ลงเครื่อง PC"
                  id="sidebar-download-app-btn"
                >
                  <Download className="w-3.5 h-3.5" />
                </button>
                <button 
                  onClick={handleRestartSystem}
                  className="p-2 bg-white/10 hover:bg-emerald-600/30 text-white/80 hover:text-white rounded-lg transition-colors cursor-pointer"
                  title="เริ่มระบบใหม่ (Restart)"
                  id="sidebar-reset-db-btn"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                </button>
                <button 
                  onClick={handleLogout}
                  className="p-2 bg-white/10 hover:bg-rose-600/30 text-white/80 hover:text-white rounded-lg transition-colors cursor-pointer"
                  title="ออกจากระบบ"
                >
                  <LogOut className="w-3.5 h-3.5" />
                </button>
              </div>
            )}
          </div>
        </div>
      </aside>

      {/* Main Area Shell */}
      <div className="flex-1 flex flex-col min-h-screen overflow-x-hidden">
        {/* Editorial Sub-Header for Active Tab and controls */}
        <header className="no-print bg-white border-b border-slate-200 md:sticky md:top-0 z-30 px-6 md:px-8 py-4 md:py-0 md:h-20 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 shrink-0">
          <div className="flex flex-wrap items-center gap-4">
            <h2 className="text-lg md:text-xl font-bold text-slate-900 uppercase tracking-wide">
              {sidebarItems.find(item => item.id === activeTab)?.label || "ภาพรวมสรุปผล"}
            </h2>
            
            {/* Elegant Month Picker Input */}
            <div className="flex items-center bg-slate-100 rounded-lg px-3 py-1.5 border border-slate-200">
              <span className="text-[10px] uppercase font-bold text-slate-400 mr-2.5 shrink-0">เลือกเดือน</span>
              <input 
                type="month" 
                value={month}
                onChange={(e) => {
                  if (e.target.value) setMonth(e.target.value);
                }}
                className="bg-transparent border-none text-xs font-black text-slate-700 focus:outline-none font-mono cursor-pointer"
              />
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={handleRestartSystem}
              className="p-1.5 text-slate-500 hover:text-emerald-600 hover:bg-emerald-50 border border-slate-200 hover:border-emerald-200 rounded-lg transition-all cursor-pointer flex items-center gap-1 shadow-sm"
              title="เริ่มระบบใหม่ (Restart)"
              id="header-reset-db-btn"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span className="text-[10px] font-bold hidden sm:inline">เริ่มระบบใหม่</span>
            </button>
            <div className="bg-[#2563eb]/5 px-3 py-1.5 rounded-lg border border-[#2563eb]/10 text-xs text-[#2563eb] font-bold">
              งวดเดือน: <span className="font-mono">{month}</span>
            </div>
          </div>
        </header>

        {/* Dynamic Panel Canvas */}
        <main className="flex-1 p-6 md:p-8 max-w-7xl w-full mx-auto">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.15 }}
            >
              {activeTab === "dashboard" && dashboardStats && (
                <Dashboard 
                  data={dashboardStats} 
                  month={month}
                  onNavigateToRooms={() => setActiveTab("rooms")}
                  lastSyncTime={lastSyncTime}
                  onSync={handlePushToSheets}
                  isSyncing={isSyncing}
                />
              )}
              {activeTab === "rooms" && (
                <Rooms 
                  rooms={rooms} 
                  banks={banks} 
                  onSave={handleSaveRoom} 
                  onDelete={handleDeleteRoom} 
                />
              )}
              {activeTab === "tenants" && (
                <Tenants 
                  tenants={tenants} 
                  rooms={rooms} 
                  onSave={handleSaveTenant} 
                  onDelete={handleDeleteTenant} 
                />
              )}
              {activeTab === "meters" && (
                <Meters 
                  list={metersList} 
                  month={month} 
                  onSaveBatch={handleSaveMetersBatch}
                  onGetAddedItems={getAddedItems}
                  onSaveAddedItem={handleSaveAddedItemWrapper}
                  onDeleteAddedItem={handleDeleteAddedItemWrapper}
                />
              )}
              {activeTab === "bills" && (
                <Bills 
                  bills={bills} 
                  banks={banks} 
                  month={month} 
                  onPayFIFO={handlePayFIFO}
                  onBulkPay={handleBulkPay}
                  onPrintInvoices={(roomIds) => {
                    setPrintConfig({
                      isOpen: true,
                      type: "invoices",
                      selectedRoomIds: roomIds
                    });
                  }}
                  onPrintSummary={(roomIds) => {
                    setPrintConfig({
                      isOpen: true,
                      type: "summary",
                      selectedRoomIds: roomIds || []
                    });
                  }}
                  onGetAddedItems={getAddedItems}
                  onSaveAddedItem={handleSaveAddedItemWrapper}
                  onDeleteAddedItem={handleDeleteAddedItemWrapper}
                />
              )}
              {activeTab === "ai" && (
                <AIAnalytics 
                  rooms={rooms}
                  bills={getBills()}
                  meters={getMeters()}
                  payments={getPaymentHistory()}
                  tenants={tenants}
                />
              )}
              {activeTab === "payments" && (
                <PaymentHistory 
                  payments={payments} 
                  bills={bills} 
                  month={month} 
                  metersList={metersList}
                  addedItemsList={addedItemsList}
                  onDeleteMeter={handleDeleteMeterReading}
                  onUpdateMeter={handleUpdateMeterReading}
                  onDeletePayment={handleDeletePayment}
                  onUpdatePayment={handleUpdatePayment}
                  onDeleteAddedItem={handleDeleteAddedItemWrapper}
                  onSaveAddedItem={handleSaveAddedItemWrapper}
                />
              )}
              {activeTab === "admin" && (
                <AdminSettings 
                  admins={admins} 
                  onSave={handleSaveAdmin} 
                  onDelete={handleDeleteAdmin} 
                  gsUrl={gsUrl}
                  onSaveGsUrl={handleSaveGsUrl}
                  onPushToSheets={handlePushToSheets}
                  onPullFromSheets={handlePullFromSheets}
                  lastSyncTime={lastSyncTime}
                  isSyncing={isSyncing}
                  utilityRates={utilityRates}
                  onSaveUtilityRate={handleSaveUtilityRate}
                  onDeleteUtilityRate={handleDeleteUtilityRate}
                  billAnnouncements={billAnnouncements}
                  onSaveBillAnnouncement={handleSaveBillAnnouncement}
                  onDeleteBillAnnouncement={handleDeleteBillAnnouncement}
                  ownerInfo={ownerInfo}
                  onSaveOwnerInfo={handleSaveOwnerInfo}
                  onResetLocalDatabase={handleResetLocalDatabase}
                  banks={banks}
                  onSaveBank={handleSaveBanks}
                  onDeleteBank={handleDeleteBanks}
                />
              )}
            </motion.div>
          </AnimatePresence>
        </main>
      </div>

      {/* A4 Portrait / Landscape Print System Render overlay */}
      {printConfig.isOpen && (
        <PrintPreview 
          type={printConfig.type}
          selectedRoomIds={printConfig.selectedRoomIds}
          bills={bills}
          rooms={rooms}
          tenants={tenants}
          banks={banks}
          month={month}
          utilityRates={utilityRates}
          billAnnouncements={billAnnouncements}
          ownerInfo={ownerInfo}
          onClose={() => setPrintConfig(prev => ({ ...prev, isOpen: false }))}
        />
      )}

      {/* Project Download to PC Modal */}
      {isDownloadModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden border border-slate-100 animate-in zoom-in-95 duration-150">
            <div className="px-6 py-4 bg-blue-600 text-white flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-1.5 bg-white/20 rounded-lg">
                  <Download className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h3 className="text-base font-extrabold leading-none">ดาวน์โหลดไฟล์ APP ลงเครื่อง PC</h3>
                  <p className="text-[11px] text-blue-100 font-medium mt-1">แพ็กซอร์สโค้ดทั้งหมดเป็นไฟล์ .ZIP เพื่อเปิดรันบนคอมพิวเตอร์</p>
                </div>
              </div>
              <button 
                onClick={() => setIsDownloadModalOpen(false)}
                className="p-1.5 hover:bg-white/20 active:bg-white/30 rounded-lg text-white transition-all cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-5 text-slate-700">
              <div className="bg-blue-50 border border-blue-100 p-4 rounded-xl space-y-3">
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                  <div>
                    <h4 className="text-sm font-bold text-blue-950 flex items-center gap-1.5">
                      <span>sabaidee-dorm-project.zip</span>
                      <span className="text-[10px] bg-blue-200 text-blue-800 px-1.5 py-0.2 rounded font-bold">~184 KB</span>
                    </h4>
                    <p className="text-xs text-blue-700 mt-0.5">รวมโค้ด React, TypeScript, Tailwind, Server และคู่มือทั้งหมด (โฟลเดอร์ sabaidee-dormitory)</p>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      onClick={handleDownloadProject}
                      disabled={isDownloadingZip}
                      className="px-4 py-2.5 bg-blue-600 hover:bg-blue-700 active:scale-95 disabled:opacity-60 text-white rounded-xl text-xs font-bold transition-all shadow-md shadow-blue-500/20 flex items-center gap-2 cursor-pointer"
                    >
                      <Download className={`w-4 h-4 ${isDownloadingZip ? "animate-bounce" : ""}`} />
                      <span>{isDownloadingZip ? "กำลังเตรียมไฟล์..." : "ดาวน์โหลดทันที"}</span>
                    </button>
                    <a
                      href="/api/download-project"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="p-2.5 bg-white hover:bg-blue-100/50 text-blue-700 border border-blue-200 rounded-xl text-xs font-bold transition-all shadow-sm"
                      title="เปิดดาวน์โหลดในแท็บใหม่ (แก้ปัญหาเบราว์เซอร์บล็อกการโหลดในเฟรม)"
                    >
                      <ExternalLink className="w-4 h-4" />
                    </a>
                  </div>
                </div>

                {/* Windows 10/11 Extract Compatibility Notice */}
                <div className="pt-2 border-t border-blue-200/60 flex items-start gap-2 text-[11px] text-blue-900 leading-relaxed font-medium">
                  <span className="text-base leading-none">✅</span>
                  <p>
                    <strong>แก้ไขปัญหากล่องข้อความ Windows "โฟลเดอร์ที่บีบอัดว่างเปล่า" เรียบร้อย:</strong> ไฟล์นี้ได้รับการสร้างโครงสร้างโฟลเดอร์ราก <code className="bg-white/80 px-1 py-0.5 rounded font-mono font-bold">sabaidee-dormitory/</code> พร้อมแฟล็กสารบบมาตรฐาน (DOS Directory Attributes) ทำให้สามารถคลิกขวาแล้วกด <strong>"แยกแฟ้มทั้งหมด... (Extract All)"</strong> บน Windows ได้ทันที หรือเปิดด้วย 7-Zip / WinRAR ได้อย่างไร้ปัญหาครับ
                  </p>
                </div>
              </div>

              <div className="space-y-2.5 text-xs text-slate-600">
                <h5 className="font-bold text-slate-900 text-sm">💻 วิธีติดตั้งและเปิดใช้งานบนเครื่องคอมพิวเตอร์ (PC):</h5>
                <ol className="list-decimal list-inside space-y-1.5 font-medium leading-relaxed">
                  <li><strong>แตกไฟล์ ZIP:</strong> คลิกขวาที่ไฟล์ <code className="bg-slate-100 px-1 py-0.5 rounded font-bold font-mono">sabaidee-dorm-project.zip</code> เลือก <strong>Extract All... (แยกแฟ้มทั้งหมด)</strong></li>
                  <li><strong>ติดตั้ง Node.js:</strong> ตรวจสอบว่าในเครื่องมี Node.js (โหลดฟรีที่ nodejs.org)</li>
                  <li><strong>เปิด Terminal / CMD:</strong> เปิดเข้าไปที่โฟลเดอร์ <code className="bg-slate-100 px-1 py-0.5 rounded font-bold font-mono">sabaidee-dormitory</code> แล้วพิมพ์คำสั่ง:</li>
                </ol>
                <div className="bg-slate-900 text-slate-100 p-3 rounded-xl font-mono text-[11px] space-y-1">
                  <p className="text-emerald-400"># 1. ติดตั้งไลบรารีของโปรเจกต์</p>
                  <p>npm install</p>
                  <p className="text-emerald-400 mt-2"># 2. เริ่มต้นรันเซิร์ฟเวอร์ระบบ</p>
                  <p>npm run dev</p>
                </div>
                <p className="text-slate-600">
                  4. เปิดเว็บเบราว์เซอร์แล้วไปที่: <span className="font-bold text-blue-600 font-mono">http://localhost:3000</span>
                </p>
              </div>

              <div className="bg-amber-50 border border-amber-200/80 p-3 rounded-xl text-[11px] text-amber-800 flex items-start gap-2">
                <Info className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                <p>
                  <strong>คำแนะนำเพิ่มเติม:</strong> ในหน้าต่าง Settings (รูปฟันเฟือง ⚙️ บนขวาของ AI Studio) คุณสามารถกดแท็บ <strong>GitHub</strong> เพื่อเชื่อมต่อและส่งโค้ดทั้งหมดขึ้น GitHub ได้โดยตรงอีกทางหนึ่งครับ
                </p>
              </div>
            </div>

            <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-100 flex justify-end">
              <button
                type="button"
                onClick={() => setIsDownloadModalOpen(false)}
                className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold transition-all cursor-pointer"
              >
                ปิดหน้าต่าง
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
